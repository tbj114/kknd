chrome.devtools.panels.create(
  "网络抓包",
  "",
  "panel.html",
  function(panel) {}
);
