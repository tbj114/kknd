const MAX_LOGS = 5000;
let logs = [];
let filteredLogs = [];
let selectedLogId = null;
let currentElements = [];
let urlFilter = 'https://api.talesofai.cn/v2/travel/parent/parent-favor/list';
let settings = {
  showAllDetails: false,
  autoFormatJson: true
};

const logBody = document.getElementById('logBody');
const detailPanel = document.getElementById('detailPanel');
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const clearBtn = document.getElementById('clearBtn');
const stats = document.getElementById('stats');
const urlFilterInput = document.getElementById('urlFilterInput');
const applyUrlFilterBtn = document.getElementById('applyUrlFilterBtn');
const settingsBtn = document.getElementById('settingsBtn');
const settingsPanel = document.getElementById('settingsPanel');
const overlay = document.getElementById('overlay');
const closeSettingsBtn = document.getElementById('closeSettingsBtn');
const showAllDetailsCheckbox = document.getElementById('showAllDetails');
const autoFormatJsonCheckbox = document.getElementById('autoFormatJson');
const elementList = document.getElementById('elementList');

console.log('网络抓包助手已启动');

function init() {
  loadSettings();
  urlFilterInput.value = urlFilter;
  setupNetworkListener();
  setupEventListeners();
}

function loadSettings() {
  try {
    const savedSettings = localStorage.getItem('networkLoggerSettings');
    if (savedSettings) {
      settings = { ...settings, ...JSON.parse(savedSettings) };
    }
  } catch (e) {
    console.error('加载设置失败:', e);
  }
  updateSettingsUI();
}

function saveSettings() {
  try {
    localStorage.setItem('networkLoggerSettings', JSON.stringify(settings));
  } catch (e) {
    console.error('保存设置失败:', e);
  }
}

function updateSettingsUI() {
  showAllDetailsCheckbox.checked = settings.showAllDetails;
  autoFormatJsonCheckbox.checked = settings.autoFormatJson;
}

function openSettings() {
  overlay.classList.remove('hidden');
  settingsPanel.classList.remove('hidden');
}

function closeSettings() {
  overlay.classList.add('hidden');
  settingsPanel.classList.add('hidden');
}

function setupNetworkListener() {
  console.log('设置网络监听器...');
  chrome.devtools.network.onRequestFinished.addListener(handleRequestFinished);
}

function handleRequestFinished(request) {
  const requestUrl = request.request.url;
  console.log('捕获到请求:', requestUrl);
  
  if (urlFilter && urlFilter.trim() !== '') {
    if (!requestUrl.includes(urlFilter.trim())) {
      console.log('URL 不匹配，跳过:', requestUrl);
      return;
    }
    console.log('URL 匹配，继续处理:', requestUrl);
  }
  
  const logEntry = {
    id: Date.now() + Math.random(),
    url: requestUrl,
    method: request.request.method,
    status: request.response ? request.response.status : 0,
    statusText: request.response ? request.response.statusText : '',
    type: getResourceType(request),
    time: new Date().toLocaleTimeString(),
    timestamp: Date.now(),
    requestHeaders: request.request ? request.request.headers : [],
    responseHeaders: request.response ? request.response.headers : [],
    requestBody: null,
    responseBody: null,
    mimeType: request.response && request.response.content ? request.response.content.mimeType : '',
    size: request.response && request.response.content ? request.response.content.size : -1
  };

  console.log('请求头数量:', logEntry.requestHeaders.length);
  console.log('响应头数量:', logEntry.responseHeaders.length);

  if (request.request && request.request.postData) {
    logEntry.requestBody = request.request.postData.text;
    console.log('获取到请求体');
  }

  addLogEntry(logEntry);

  if (request.getContent) {
    try {
      request.getContent((content, encoding) => {
        console.log('获取到响应体, 编码:', encoding, '长度:', content ? content.length : 0);
        logEntry.responseBody = content;
        logEntry.responseEncoding = encoding;
        updateLogEntry(logEntry);
      });
    } catch (e) {
      console.error('获取响应体失败:', e);
    }
  } else {
    console.log('getContent 方法不可用');
  }
}

function getResourceType(request) {
  if (request._resourceType) return request._resourceType;
  if (request.response && request.response.content && request.response.content.mimeType) {
    const mimeType = request.response.content.mimeType;
    if (mimeType.includes('html')) return 'document';
    if (mimeType.includes('css')) return 'stylesheet';
    if (mimeType.includes('javascript') || mimeType.includes('script')) return 'script';
    if (mimeType.includes('image')) return 'image';
    if (mimeType.includes('font')) return 'font';
    if (mimeType.includes('json')) return 'xhr';
  }
  return 'other';
}

function addLogEntry(logEntry) {
  logs.unshift(logEntry);
  
  if (logs.length > MAX_LOGS) {
    logs.pop();
  }

  applyFilter();
}

function updateLogEntry(updatedLog) {
  const index = logs.findIndex(log => log.id === updatedLog.id);
  if (index !== -1) {
    logs[index] = updatedLog;
    if (selectedLogId === updatedLog.id) {
      renderDetail(updatedLog);
    }
  }
}

function renderLogs() {
  logBody.innerHTML = '';
  
  filteredLogs.forEach(log => {
    const tr = document.createElement('tr');
    tr.dataset.id = log.id;
    tr.innerHTML = `
      <td class="method-${log.method.toLowerCase()}">${log.method}</td>
      <td class="status-${Math.floor(log.status / 100)}xx">${log.status}</td>
      <td>${log.type}</td>
      <td title="${log.url}">${log.url}</td>
      <td>${log.time}</td>
    `;
    tr.addEventListener('click', () => selectLog(log.id));
    if (log.id === selectedLogId) {
      tr.classList.add('selected');
    }
    logBody.appendChild(tr);
  });

  stats.textContent = `${filteredLogs.length} 条记录`;
}

function selectLog(id) {
  selectedLogId = id;
  const log = logs.find(l => l.id === id);
  if (log) {
    console.log('选中记录:', log);
    renderDetail(log);
  }
  renderLogs();
}

function renderDetail(log) {
  if (settings.showAllDetails) {
    renderFullDetail(log);
  } else {
    renderSimpleDetail(log);
  }
  analyzeAndRenderElements(log);
}

function analyzeAndRenderElements(log) {
  currentElements = [];
  if (!log.responseBody) {
    elementList.innerHTML = '<div class="element-bar-empty">无响应体数据</div>';
    return;
  }

  try {
    const jsonBody = JSON.parse(log.responseBody);
    if (jsonBody.list && Array.isArray(jsonBody.list)) {
      currentElements = jsonBody.list;
      renderElementList();
    } else {
      elementList.innerHTML = '<div class="element-bar-empty">响应体中未找到元素列表</div>';
    }
  } catch (e) {
    elementList.innerHTML = '<div class="element-bar-empty">解析响应体失败</div>';
  }
}

function renderElementList() {
  if (currentElements.length === 0) {
    elementList.innerHTML = '<div class="element-bar-empty">没有找到元素</div>';
    return;
  }

  elementList.innerHTML = currentElements.map((element, index) => {
    const headerImg = element.config?.header_img || element.config?.avatar_img || element.oc?.url || '';
    const name = element.name || element.short_name || '未命名';
    return `
      <div class="element-card" data-index="${index}">
        <img src="${headerImg}" alt="${escapeHtml(name)}" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22140%22 height=%22140%22 viewBox=%220 0 140 140%22><rect fill=%22%233c3c3c%22 width=%22140%22 height=%22140%22/><text x=%2270%22 y=%2275%22 font-size=%2214%22 fill=%22%23808080%22 text-anchor=%22middle%22>无图</text></svg>'">
        <div class="name">${escapeHtml(name)}</div>
      </div>
    `;
  }).join('');

  const cards = elementList.querySelectorAll('.element-card');
  cards.forEach(card => {
    card.addEventListener('click', () => {
      const index = parseInt(card.dataset.index, 10);
      showElementDetail(index);
    });
  });
}

function showElementDetail(index) {
  const element = currentElements[index];
  if (!element) return;

  const headerImg = element.config?.header_img || element.config?.avatar_img || element.oc?.url || '';
  const name = element.name || element.short_name || '未命名';

  let refImg = '';
  if (element.oc?.mix_meta && element.oc.mix_meta.length > 0) {
    const params = element.oc.mix_meta[0].params;
    refImg = params?.ref_image_url || params?.image_url || params?.controlnetunit_tile_image_ref || '';
  }

  let positivePrompt = '';
  if (element.oc?.mix_meta && element.oc.mix_meta.length > 0) {
    positivePrompt = element.oc.mix_meta[0].params?.positive_prompt || '';
  }

  const newWindow = window.open('', '_blank', 'width=800,height=900,resizable=yes,scrollbars=yes');
  
  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>${escapeHtml(name)} - 元素详情</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          background: #1e1e1e;
          color: #d4d4d4;
          padding: 20px;
        }
        h1 {
          font-size: 24px;
          margin-bottom: 20px;
          color: #cccccc;
          border-bottom: 1px solid #3c3c3c;
          padding-bottom: 10px;
        }
        .images-section {
          display: flex;
          gap: 20px;
          margin-bottom: 20px;
        }
        .image-container {
          flex: 1;
        }
        .image-container h2 {
          font-size: 14px;
          margin-bottom: 10px;
          color: #9cdcfe;
        }
        .image-container img {
          max-width: 100%;
          max-height: 400px;
          border-radius: 8px;
          border: 1px solid #3c3c3c;
        }
        .section {
          margin-bottom: 20px;
        }
        .section h2 {
          font-size: 16px;
          margin-bottom: 10px;
          color: #9cdcfe;
        }
        pre {
          background: #252526;
          padding: 15px;
          border: 1px solid #3c3c3c;
          border-radius: 4px;
          white-space: pre-wrap;
          word-break: break-all;
          font-size: 13px;
          line-height: 1.6;
        }
        .info-item {
          margin-bottom: 8px;
        }
        .info-label {
          color: #9cdcfe;
          margin-right: 8px;
        }
      </style>
    </head>
    <body>
      <h1>${escapeHtml(name)}</h1>
      
      <div class="images-section">
        ${headerImg ? `
          <div class="image-container">
            <h2>头图</h2>
            <img src="${headerImg}" alt="头图">
          </div>
        ` : ''}
        ${refImg ? `
          <div class="image-container">
            <h2>参考图</h2>
            <img src="${refImg}" alt="参考图">
          </div>
        ` : ''}
      </div>
      
      <div class="section">
        <h2>正面描述词</h2>
        <pre>${escapeHtml(positivePrompt || '无正面描述词')}</pre>
      </div>
      
      <div class="section">
        <h2>元素信息</h2>
        <div class="info-item">
          <span class="info-label">UUID:</span>
          <span>${escapeHtml(element.uuid || '-')}</span>
        </div>
        <div class="info-item">
          <span class="info-label">创建者:</span>
          <span>${escapeHtml(element.creator?.nick_name || '-')}</span>
        </div>
        <div class="info-item">
          <span class="info-label">热度:</span>
          <span>${element.heat_score || 0}</span>
        </div>
      </div>
    </body>
    </html>
  `;

  newWindow.document.write(htmlContent);
  newWindow.document.close();
}

function renderSimpleDetail(log) {
  let responseBodyDisplay = '';
  if (log.responseBody) {
    if (settings.autoFormatJson && log.mimeType && log.mimeType.includes('json')) {
      try {
        const jsonBody = JSON.parse(log.responseBody);
        responseBodyDisplay = JSON.stringify(jsonBody, null, 2);
      } catch {
        responseBodyDisplay = log.responseBody;
      }
    } else {
      responseBodyDisplay = log.responseBody;
    }
  } else {
    responseBodyDisplay = '(响应体加载中或为空)';
  }

  detailPanel.innerHTML = `
    <div style="margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;">
      <div>
        <span style="color: #9cdcfe; font-weight: bold;">${log.method}</span>
        <span style="margin-left: 8px; color: ${log.status >= 200 && log.status < 300 ? '#4ec9b0' : '#f44747'};">${log.status}</span>
        <span style="margin-left: 8px; color: #808080;">${log.url}</span>
      </div>
      <button class="secondary copy-btn" onclick="copyResponseBody()">复制</button>
    </div>
    <pre>${escapeHtml(responseBodyDisplay)}</pre>
  `;
}

function renderFullDetail(log) {
  console.log('渲染详情, 请求头:', log.requestHeaders);
  
  let requestHeadersHtml = '';
  if (log.requestHeaders && log.requestHeaders.length > 0) {
    requestHeadersHtml = log.requestHeaders.map(h => 
      `<div class="detail-item"><span class="detail-label">${escapeHtml(h.name)}:</span><span class="detail-value">${escapeHtml(h.value)}</span></div>`
    ).join('');
  } else {
    requestHeadersHtml = '<div class="detail-item">无请求头</div>';
  }

  let responseHeadersHtml = '';
  if (log.responseHeaders && log.responseHeaders.length > 0) {
    responseHeadersHtml = log.responseHeaders.map(h => 
      `<div class="detail-item"><span class="detail-label">${escapeHtml(h.name)}:</span><span class="detail-value">${escapeHtml(h.value)}</span></div>`
    ).join('');
  } else {
    responseHeadersHtml = '<div class="detail-item">无响应头</div>';
  }

  let responseBodyDisplay = '';
  if (log.responseBody) {
    if (settings.autoFormatJson && log.mimeType && log.mimeType.includes('json')) {
      try {
        const jsonBody = JSON.parse(log.responseBody);
        responseBodyDisplay = JSON.stringify(jsonBody, null, 2);
      } catch {
        responseBodyDisplay = log.responseBody;
      }
    } else {
      responseBodyDisplay = log.responseBody;
    }
  } else {
    responseBodyDisplay = '(响应体加载中或为空)';
  }

  detailPanel.innerHTML = `
    <div class="detail-section">
      <h3>基本信息</h3>
      <div class="detail-item"><span class="detail-label">URL:</span><span class="detail-value">${escapeHtml(log.url)}</span></div>
      <div class="detail-item"><span class="detail-label">方法:</span><span class="detail-value">${log.method}</span></div>
      <div class="detail-item"><span class="detail-label">状态:</span><span class="detail-value">${log.status} ${escapeHtml(log.statusText)}</span></div>
      <div class="detail-item"><span class="detail-label">类型:</span><span class="detail-value">${log.type}</span></div>
      <div class="detail-item"><span class="detail-label">大小:</span><span class="detail-value">${formatSize(log.size)}</span></div>
      <div class="detail-item"><span class="detail-label">MIME类型:</span><span class="detail-value">${escapeHtml(log.mimeType || '未知')}</span></div>
      <div class="detail-item"><span class="detail-label">时间:</span><span class="detail-value">${log.time}</span></div>
    </div>
    
    <div class="detail-section">
      <h3>请求头 (${log.requestHeaders ? log.requestHeaders.length : 0})</h3>
      ${requestHeadersHtml}
    </div>
    
    ${log.requestBody ? `
    <div class="detail-section">
      <h3>请求体</h3>
      <pre>${escapeHtml(log.requestBody)}</pre>
    </div>
    ` : ''}
    
    <div class="detail-section">
      <h3>响应头 (${log.responseHeaders ? log.responseHeaders.length : 0})</h3>
      ${responseHeadersHtml}
    </div>
    
    <div class="detail-section">
      <h3>响应体</h3>
      <pre>${escapeHtml(responseBodyDisplay)}</pre>
    </div>
  `;
}

function copyResponseBody() {
  const log = logs.find(l => l.id === selectedLogId);
  if (log && log.responseBody) {
    navigator.clipboard.writeText(log.responseBody).then(() => {
      alert('响应体已复制到剪贴板');
    }).catch(err => {
      console.error('复制失败:', err);
    });
  }
}

function formatSize(bytes) {
  if (bytes === -1) return '未知';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function applyFilter() {
  const searchTerm = searchInput.value.toLowerCase().trim();
  
  if (!searchTerm) {
    filteredLogs = [...logs];
  } else {
    filteredLogs = logs.filter(log => {
      if (log.url && log.url.toLowerCase().includes(searchTerm)) return true;
      if (log.method && log.method.toLowerCase().includes(searchTerm)) return true;
      if (String(log.status).includes(searchTerm)) return true;
      if (log.type && log.type.toLowerCase().includes(searchTerm)) return true;
      if (log.responseBody && log.responseBody.toLowerCase().includes(searchTerm)) return true;
      if (log.requestBody && log.requestBody.toLowerCase().includes(searchTerm)) return true;
      return false;
    });
  }
  
  renderLogs();
}

function setupEventListeners() {
  searchBtn.addEventListener('click', applyFilter);
  searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') applyFilter();
  });
  
  applyUrlFilterBtn.addEventListener('click', () => {
    urlFilter = urlFilterInput.value;
    console.log('URL 过滤器已更新为:', urlFilter);
  });
  
  urlFilterInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      urlFilter = urlFilterInput.value;
      console.log('URL 过滤器已更新为:', urlFilter);
    }
  });
  
  clearBtn.addEventListener('click', () => {
    logs = [];
    filteredLogs = [];
    selectedLogId = null;
    currentElements = [];
    renderLogs();
    detailPanel.innerHTML = '<div class="empty-state">选择一条记录查看详情</div>';
    elementList.innerHTML = '<div class="element-bar-empty">选择网络日志查看元素</div>';
  });

  settingsBtn.addEventListener('click', openSettings);
  overlay.addEventListener('click', closeSettings);
  closeSettingsBtn.addEventListener('click', closeSettings);

  showAllDetailsCheckbox.addEventListener('change', () => {
    settings.showAllDetails = showAllDetailsCheckbox.checked;
    saveSettings();
    if (selectedLogId) {
      const log = logs.find(l => l.id === selectedLogId);
      if (log) renderDetail(log);
    }
  });

  autoFormatJsonCheckbox.addEventListener('change', () => {
    settings.autoFormatJson = autoFormatJsonCheckbox.checked;
    saveSettings();
    if (selectedLogId) {
      const log = logs.find(l => l.id === selectedLogId);
      if (log) renderDetail(log);
    }
  });
}

init();
